from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator

class Opera(models.Model):
    name = models.CharField(max_length=100)
    desc = models.TextField()
    date = models.IntegerField()
    image = models.ImageField(upload_to='immagini', blank=True, null=True)

class User(models.Model):
    userHash = models.CharField(max_length=255)
    mail = models.CharField(max_length=100)

class Slot(models.Model):
    image = models.ImageField(upload_to='immagini', blank=True, null=True)

class Giocata(models.Model):
    tentativi = models.IntegerField()
    date = models.IntegerField()
    slot1 = models.ForeignKey(Slot, on_delete=models.CASCADE, related_name='giocate_slot1')
    slot2 = models.ForeignKey(Slot, on_delete=models.CASCADE, related_name='giocate_slot2')
    slot3 = models.ForeignKey(Slot, on_delete=models.CASCADE, related_name='giocate_slot3')
    user = models.ForeignKey(User, on_delete=models.CASCADE)

class JackPot(models.Model):
    desc = models.TextField()
    image = models.ImageField(upload_to='immagini', blank=True, null=True)
    messaggio = models.TextField()
    
class Review(models.Model):
    review = models.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(10)])
    desc = models.TextField(max_length=255)
    name = models.CharField(max_length=255)
    title = models.TextField(max_length=255)