from django import forms

class LoginForm(forms.Form):
    mail = forms.CharField(max_length=100)
    password = forms.CharField(max_length=18)

class ReviewForm(forms.Form):
    titolo = forms.CharField(max_length=255)
    rating = forms.IntegerField()
    descrizione = forms.CharField(max_length=255)
    nome = forms.CharField(max_length=255)
    