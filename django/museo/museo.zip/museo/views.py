from django.shortcuts import render
from django.http import HttpResponse
from .forms import LoginForm, ReviewForm
from .models import Opera, Review, User

# Create your views here.
def index(request):
    return render(request,"homepage.html")

def galleria(request):
    opere = Opera.objects.all().order_by("date") #prende tutte le opere in ordine di data per linea temporale
    return render(request,"galleria.html",{"opere": opere})

def master(request):
    return render(request,"master.html")

def slot(request):
    return render(request, "slot.html")

# richiesta per pagina di login
def login(request):
    context = {} # array di contenuti da passare a pagina
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            User.objects.create(
                userHash=form.cleaned_data['password'],
                mail=form.cleaned_data['mail']
            )
            form = LoginForm()
    else:
        form = LoginForm()
        
    context["form"] = LoginForm() # aggiunge form ad array
    return render(request,"login.html",context) #passa dati a pagina

def registrazione(request):
    return render(request,"registrazione.html")

def review(request):
    context = {} # crea array di cose da dare alla pagina

    if request.method == 'POST': # se post da form
        form = ReviewForm(request.POST) # prende dati form
        if form.is_valid(): # controlla validita
            Review.objects.create( # crea nuova riga nella table
                review=form.cleaned_data['rating'],
                desc=form.cleaned_data['descrizione'],
                name=form.cleaned_data['nome'],
                title=form.cleaned_data['titolo']
            )
            form = ReviewForm() # pulisce form
    else: # se pag chiamata solo per visualizzazione
        form = ReviewForm() # crea una form

    # Add form and reviews to the context
    context["form"] = form
    context["reviews"] = Review.objects.all()

    return render(request, "review.html", context)
