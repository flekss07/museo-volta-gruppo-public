from django.db import models

class Autore(models.Model):
    name = models.CharField(max_length=200)
    surname = models.CharField(max_length=200)
    nationality = models.CharField(max_length=200)
    birth_date = models.DateField()
    death_date = models.DateField()
    description = models.TextField()
    photo = models.ImageField(upload_to='media/imgsrc/', blank=True, null=True)

    def __str__(self):
        return self.name + " " + self.surname


class Opera(models.Model):
    title = models.CharField(max_length=200)
    year = models.IntegerField()
    author = models.ForeignKey(Autore, on_delete=models.CASCADE)

    def __str__(self):
        return self.title
