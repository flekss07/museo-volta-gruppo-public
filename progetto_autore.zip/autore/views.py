from django.shortcuts import render, get_object_or_404
from .models import Autore, Opera

def dettaglio_autore(request, id):
    autore = get_object_or_404(Autore, pk=id)
    opere = Opera.objects.filter(author=id)
    return render(request, 'dettaglio_autore.html', {'autore': autore, 'opere': opere})
